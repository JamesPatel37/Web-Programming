package cs320.GuestBook;

import java.util.Date;

public class GuestBookPost {

	String message;
	Date date;
	String name;
	
	public GuestBookPost(String message, String name) {
		super();
		this.message = message;
		this.name = name;
		this.date = new Date();
	}

	public String getMessage() {
		return message;
	}

	public Date getDate() {
		return date;
	}

	public String getName() {
		return name;
	}
	
	
	
}
