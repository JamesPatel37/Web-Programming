package cs320.GuestBook;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GuestBook/GuestBookServlet")
public class GuestBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	public void init() throws ServletException {
		
		if ( this.getServletContext().getAttribute("GuestBookPosts") == null)
		{
			ArrayList<GuestBookPost> posts = new ArrayList<GuestBookPost>();
			posts.add(new GuestBookPost("Hello, World!", "John Doe"));
			posts.add(new GuestBookPost("Game Over!", "Joe Boxer"));
			this.getServletContext().setAttribute("GuestBookPosts", posts);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		ServletContext context = this.getServletContext();
		ArrayList<GuestBookPost> posts = (ArrayList<GuestBookPost>) context.getAttribute("GuestBookPosts");
		
		out.println("<!doctype html>");
		out.println("<html>");
		out.println("	<head>");
		out.println(" 		<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css\">");
		out.println("	</head>");
		out.println("	<body>");
		out.println(" 		<h1>Guest Book Servlet <small>CS320</small></h1><hr />");
		
		for (GuestBookPost post : posts){
			out.println("<p class=\"lead\">" 
						+ post.getMessage() 
						+ " - <strong>" 
						+ post.getName()
						+ "</strong><small>"
						+ post.getDate() + "</small></p>");
		}
		
		out.println("<form action=\"GuestBookServlet\" method=\"post\">");
		out.println("   <input type=\"text\" name=\"name\" placeholder=\"Enter your name\" /><br />");
		out.println("   <textarea name=\"message\" rows=\"3\" cols=\"15\" placeholder=\"Enter a message\"></textarea><br />");
		out.println("   <input type=\"submit\" value=\"Post\" />");
		out.println("</form>");
		
		out.println("	</body>");
		out.println("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (    request.getParameter("name") != null 
				&& request.getParameter("name").trim().length() > 0
				&& request.getParameter("message") != null 
				&& request.getParameter("message").trim().length() > 0)
		{
			ArrayList<GuestBookPost> posts = (ArrayList<GuestBookPost>) this.getServletContext().getAttribute("GuestBookPosts");
			posts.add( new GuestBookPost( request.getParameter("message"), request.getParameter("name") ));
		}
		
		doGet(request, response);
	}

}
