package cs320.responses;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/responses/CountdownServlet")
public class CountdownServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	public void init() throws ServletException {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		//response.setContentType("application/vnd.ms-excel");
		
		int count = 0;
		
		// If the User did not specify a count in the query string,
		// read it from the cookie
		if ( request.getParameter("count") == null){
			// Is there a cookie that we can read from?
			Cookie[] cookies = request.getCookies();
			
			if( cookies != null ){
				for (int i = 0; i < cookies.length; i++){
					Cookie c = cookies[i];
					if (c.getName().equals("count") ){
						
						// Read the current value of count
						count = Integer.parseInt(c.getValue());
						
						// Update the value of count in the cookie
						response.addCookie(new Cookie("count", Integer.toString(--count)));
						
						if (count > 0){
							// Set my refresh header
							response.setIntHeader("Refresh",  1);
						}
						
						break;
					}
				}
			}
		}
		
		
		try{
			count = Integer.parseInt(request.getParameter("count"));			
			
			// Save the value of 'count' to a cookie
			Cookie cookie = new Cookie("count", Integer.toString(count) );
			response.addCookie( cookie );
			
			//response.setIntHeader("Refresh",  1);
			response.sendRedirect("CountdownServlet");
		}catch(Exception e){			
		}
		
		
		
		
		PrintWriter out = response.getWriter();
		
		
		out.println("<!doctype html>");
		out.println("<html>");
		out.println("	<head>");
		out.println(" 		<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css\">");
		out.println("	</head>");
		out.println("	<body>");
		out.println(" 		<h1>Countdown Servlet <small>CS320</small></h1><hr />");
		out.println("       <h3>" + count + "</h3>");
		out.println("       <p class=\"lead\">");
		out.println( new Date());
		out.println("       </p>");
		out.println("	</body>");
		out.println("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
