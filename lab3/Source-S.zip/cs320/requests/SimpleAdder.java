package cs320.requests;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/requests/SimpleAdder")
public class SimpleAdder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		boolean formWasSubmitted = (request.getParameter("num1") != null || request.getParameter("num2") != null);
		
		boolean isNum1Valid = true;
		boolean isNum2Valid = true;
		int num1 = 0, num2 = 0, sum = 0;
		
		if ( request.getParameter("num1") != null ){ 
			try{
				num1 = Integer.parseInt( request.getParameter("num1") );
			}catch(Exception e){
				isNum1Valid = false;
			}
		}
		
		if ( request.getParameter("num2") != null ){ 
			try{
				num2 = Integer.parseInt( request.getParameter("num2") );
			}catch(Exception e){
				isNum2Valid = false;
			}
		}
		
		
		if (isNum1Valid && isNum2Valid)
			sum = num1 + num2;
		else{
			// Redirect the User to an error page
			response.sendRedirect("Error.html");
		}
			
				
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();		
		
		out.println("<!doctype html>");
		out.println("<html>");
		out.println("	<head>");
		out.println(" 		<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css\">");
		out.println("	</head>");
		out.println("	<body>");
		out.println(" 		<h1>Simple Adder <small>CS320</small></h1><hr />");
		
		out.println("<form action=\"SimpleAdder\" method=\"get\">");
		
		out.println("<input type=\"hidden\" name=\"PayPalID\" value=\"a234asd12\" />");
		
		
		out.print("   <input type=\"text\" ");
		
		if (formWasSubmitted && isNum1Valid)
			out.print(" value=\"" + num1 + "\" ");
		
		out.println(" name=\"num1\" placeholder=\"Enter a number\" /> +");
		
		
		out.print("   <input type=\"text\" ");
		if (formWasSubmitted && isNum2Valid)
			out.print(" value=\"" + num2 + "\" ");
		out.println("   name=\"num2\" placeholder=\"Enter another number\" /> =");
		
		
		out.print("   <input type=\"text\" readonly ");
		if (formWasSubmitted)
			out.print(" value=\"" + sum + "\" ");
		out.println(" placeholder=\"The Sum\" /> <br />");
		
		out.println("   <input type=\"submit\" value=\"Add\" class=\"btn btn-primary\" />");
		out.println("</form>");
		
		out.println("	</body>");
		out.println("</html>");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
