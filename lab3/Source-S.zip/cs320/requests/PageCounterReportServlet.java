package cs320.requests;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/requests/PageCounterReportServlet")
public class PageCounterReportServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    
	public void init() throws ServletException {
		ServletContext context = this.getServletContext();
		if (context.getAttribute("pageCounter") == null)
			context.setAttribute("pageCounter", 0);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		ServletContext context = this.getServletContext();
		int count = (int) context.getAttribute("pageCounter");
		
		out.println("<!doctype html>");
		out.println("<html>");
		out.println("	<head>");
		out.println(" 		<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css\">");
		out.println("	</head>");
		out.println("	<body>");
		out.println(" 		<h1><small>Page Counter has been viewed: </small> ");
		out.println( count );
		out.println(" time(s).</h1>");		
		out.println("	</body>");
		out.println("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
