package cs320.beans;

public class PageDataBean {
	private String pageTitle;	
	
	public PageDataBean(){
		this.pageTitle = "Page Title Not Set";
	}
	
	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	
	
}
