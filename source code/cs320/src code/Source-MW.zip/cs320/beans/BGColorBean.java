package cs320.beans;

public class BGColorBean {

	private int r,g,b;

	public BGColorBean() {
		r = 255;
		g = 0;
		b = 0;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}
	
	
	
	
}
